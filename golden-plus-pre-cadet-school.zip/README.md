# Golden Plus Pre-Cadet School Website

Modern responsive school website with:
- Glassmorphism / iOS-inspired visual style
- Motion/reveal animations
- Responsive mobile navigation
- Hero section
- About section
- Programs: Play, Nursery, KG, Class 1–5
- Teacher profiles
- Facilities / school strengths
- Admission CTA
- Contact section

## Known school information included
- Name: GOLDEN PLUS PRE-CADET SCHOOL
- Tagline: Bright Future Begins Here
- Programs: Play, Nursery, KG, Class 1–5
- English Version
- Religious Education
- Moral Education
- Experienced Teachers
- Play & Learning
- Address: গোপালপুর কমপ্লেক্স জেনারেল হাসপাতালের পাশে, লালপুর, নাটোর
- Phone: ০১৭৯২৭৯৬৬৮০

## Important
Teacher names/photos are intentionally editable placeholders because verified teacher details were not available in the supplied information.

## GitHub Pages
Upload `index.html`, `style.css`, and `script.js` to a GitHub repository.
Then enable GitHub Pages from:
Settings → Pages → Deploy from branch → main → /(root)
